﻿const crypto = require("crypto");
exports.handler = async function(event) {
  try {
    if (event.httpMethod !== "POST") return { statusCode: 405 };
    const { html, token, siteId } = JSON.parse(event.body);
    if (!html) return { statusCode: 400 };

    const sha256 = (s) => crypto.createHash("sha256").update(s, "utf8").digest("hex");

    const api = async (m, p, b) => {
      const r = await fetch("https://api.netlify.com/api/v1/" + p, {
        method: m,
        headers: { "Authorization": "Bearer " + token, "Content-Type": "application/json" },
        body: b ? JSON.stringify(b) : undefined
      });
      const t = await r.text();
      if (!r.ok) throw new Error(m + " " + p + ": " + r.status + " " + t.slice(0, 200));
      return t ? JSON.parse(t) : null;
    };

    // Try creating deploy with file content directly in files field
    const deploy = await api("POST", "sites/" + siteId + "/deploys", {
      files: { "index.html": html }
    });
    
    return { statusCode: 200, body: JSON.stringify({ success: true, deployId: deploy.id }) };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
};